import { useTheme } from "./ThemeProvider";
import { FaLinkedin } from "react-icons/fa";
import { MoonIcon, SunIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function Header() {
  const { theme, setTheme } = useTheme();
  const [isDarkMode, setIsDarkMode] = useState(false);
  const { toast } = useToast();
  
  // Keep local state in sync with global theme
  useEffect(() => {
    setIsDarkMode(theme === "dark");
  }, [theme]);

  const toggleTheme = () => {
    const newTheme = isDarkMode ? "light" : "dark";
    setIsDarkMode(!isDarkMode);
    setTheme(newTheme);
    
    // Force a document class update in case the theme provider didn't catch it
    document.documentElement.classList.remove("light", "dark");
    document.documentElement.classList.add(newTheme);
    
    // Log for debugging
    console.log("Toggled theme to:", newTheme);
    
    // Notify user
    toast({
      title: `${isDarkMode ? "Light" : "Dark"} mode activated`,
      description: `Switched to ${isDarkMode ? "light" : "dark"} theme`,
      duration: 1500,
    });
  };

  return (
    <header className="bg-white dark:bg-gray-800 shadow-sm sticky top-0 z-10">
      <div className="flex justify-between items-center px-4 py-3">
        <div className="flex items-center">
          <FaLinkedin className="text-linkedin-blue text-2xl mr-2" />
          <h1 className="font-bold text-lg text-linkedin-text dark:text-white">
            LinkedIn Comment Generator
          </h1>
        </div>
        <Button
          onClick={toggleTheme}
          variant="ghost"
          size="icon"
          className="rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
          aria-label="Toggle dark mode"
        >
          {isDarkMode ? (
            <SunIcon className="h-5 w-5 text-yellow-300" />
          ) : (
            <MoonIcon className="h-5 w-5 text-gray-600 dark:text-blue-400" />
          )}
        </Button>
      </div>
    </header>
  );
}
