import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import { Copy, Share, Edit, AlertTriangle } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { deepseekService } from "@/services/deepseekService";
import { useLocation } from "wouter";
import { saveComment } from "@/lib/comments";

// Detect if we're running in static mode (no server)
const isStaticBuild = typeof window !== "undefined" && window.location.protocol === "file:";

interface Comment {
  id?: number;
  content: string;
  tone: string;
  type?: 'standard' | 'one-line';
}

interface GeneratedCommentsProps {
  comments: Comment[];
  originalPost: string;
}

export default function GeneratedComments({ comments, originalPost }: GeneratedCommentsProps) {
  const [editingComment, setEditingComment] = useState<Comment | null>(null);
  const [editedContent, setEditedContent] = useState("");
  const { toast } = useToast();

  const getBadgeColor = (tone: string) => {
    switch (tone) {
      case "professional":
        return "bg-blue-600";
      case "friendly":
        return "bg-yellow-500";
      case "funny":
        return "bg-purple-500";
      case "supportive":
        return "bg-green-600";
      case "insightful":
        return "bg-orange-500";
      case "storytelling":
        return "bg-pink-500";
      default:
        return "bg-gray-500";
    }
  };
  
  // Group comments by type
  const standardComments = comments.filter(c => !c.type || c.type === 'standard');
  const oneLineComments = comments.filter(c => c.type === 'one-line');

  // Static build checks
  const [hasApiKey, setHasApiKey] = useState(true);
  const [, navigate] = useLocation();
  
  // Check for API key on mount if static build
  useEffect(() => {
    if (isStaticBuild) {
      setHasApiKey(deepseekService.hasApiKey());
    }
  }, []);
  
  // Go to settings page to set API key
  const handleGoToSettings = () => {
    navigate("/settings");
  };
  
  const saveMutation = useMutation({
    mutationFn: async (comment: Comment) => {
      if (isStaticBuild) {
        return await saveComment(comment.content, comment.tone as any, originalPost);
      } else {
        const response = await apiRequest("POST", "/api/comments", {
          content: comment.content,
          tone: comment.tone,
          originalPost,
        });
        return response.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/comments"] });
      toast({
        variant: "success",
        title: "Saved",
        description: "Comment saved to history",
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to save comment",
      });
    },
  });

  const handleCopyComment = (content: string) => {
    navigator.clipboard.writeText(content);
    toast({
      variant: "success",
      title: "Copied",
      description: "Comment copied to clipboard",
    });
  };

  const handleShareToLinkedIn = (content: string) => {
    // Encoding the comment to be included in the URL
    const encodedText = encodeURIComponent(content);
    // Open LinkedIn in a new tab with the pre-filled comment
    window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodedText}`, "_blank");
  };

  const handleEditComment = (comment: Comment) => {
    setEditingComment(comment);
    setEditedContent(comment.content);
  };

  const saveEditedComment = () => {
    if (editingComment) {
      const updatedComment = { ...editingComment, content: editedContent };
      setEditingComment(null);
      
      // Update the comment in the local state
      const index = comments.findIndex(c => c.content === editingComment.content);
      if (index !== -1) {
        comments[index] = updatedComment;
      }
    }
  };

  const handleSaveComment = (comment: Comment) => {
    saveMutation.mutate(comment);
  };

  return (
    <>
      <div className="space-y-4 mb-8">
        <div className="flex justify-between items-center mb-2">
          <h2 className="font-semibold text-lg text-linkedin-text dark:text-white">
            Generated Comments
          </h2>
          <span className="text-sm text-linkedin-darkGray dark:text-gray-400">
            {formatDistanceToNow(new Date(), { addSuffix: true })}
          </span>
        </div>

        {isStaticBuild && !hasApiKey && (
          <Alert className="mb-4 border-yellow-500 bg-yellow-50 dark:bg-yellow-900/20">
            <AlertTriangle className="h-4 w-4 text-yellow-600 dark:text-yellow-500" />
            <AlertDescription className="flex items-center justify-between">
              <span>You need to set up your DeepSeek API key to generate comments in static mode.</span>
              <Button 
                onClick={handleGoToSettings}
                size="sm"
                variant="outline"
                className="border-yellow-500 text-yellow-600 hover:bg-yellow-50 dark:text-yellow-500 dark:hover:bg-yellow-900/40 ml-2"
              >
                Go to Settings
              </Button>
            </AlertDescription>
          </Alert>
        )}
        
        {comments.length === 0 ? (
          <Card>
            <CardContent className="p-4 text-center text-linkedin-darkGray dark:text-gray-400">
              Generate comments to see them here
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Standard Comments Section */}
            {standardComments.length > 0 && (
              <div className="mb-4">
                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 ml-1">
                  Standard Comments
                </h3>
                {standardComments.map((comment, index) => (
                  <Card key={`standard-${index}`} className="overflow-hidden mb-3 shadow-md dark:border-gray-700">
                    <CardContent className="p-4">
                      <div className="flex justify-between mb-3">
                        <div className="flex gap-2">
                          <Badge className={`${getBadgeColor(comment.tone)} capitalize`}>
                            {comment.tone}
                          </Badge>
                        </div>
                        <div className="flex space-x-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleCopyComment(comment.content)}
                            title="Copy comment"
                            className="h-8 w-8"
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleShareToLinkedIn(comment.content)}
                            title="Share to LinkedIn"
                            className="h-8 w-8"
                          >
                            <Share className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEditComment(comment)}
                            title="Edit comment"
                            className="h-8 w-8"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <p className="text-gray-800 dark:text-gray-100 text-sm leading-relaxed mb-3">
                        {comment.content}
                      </p>
                      <div className="flex justify-end">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleSaveComment(comment)}
                          className="text-xs bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700"
                        >
                          Save
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {/* One-Line Comments Section */}
            {oneLineComments.length > 0 && (
              <div className="mt-6">
                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 ml-1">
                  One-Line Comments
                </h3>
                <div className="bg-white dark:bg-gray-800 shadow rounded-lg p-3">
                  {oneLineComments.map((comment, index) => (
                    <div 
                      key={`oneline-${index}`} 
                      className={`
                        p-3 mb-2 rounded-md flex items-center justify-between
                        ${index % 2 === 0 ? 'bg-gray-50 dark:bg-gray-700' : 'bg-white dark:bg-gray-800'}
                        border border-gray-100 dark:border-gray-700
                      `}
                    >
                      <div className="flex items-center gap-2">
                        <Badge className={`${getBadgeColor(comment.tone)} capitalize text-xs px-2 py-0.5`}>
                          {comment.tone}
                        </Badge>
                        <p className="text-gray-800 dark:text-gray-100 text-sm ml-2">
                          {comment.content}
                        </p>
                      </div>
                      <div className="flex gap-1 ml-2 flex-shrink-0">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleCopyComment(comment.content)}
                          title="Copy"
                          className="h-6 w-6"
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleSaveComment(comment)}
                          title="Save"
                          className="h-6 w-6"
                        >
                          <Edit className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>

      <Dialog 
        open={editingComment !== null} 
        onOpenChange={(open) => !open && setEditingComment(null)}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Comment</DialogTitle>
          </DialogHeader>
          <Textarea
            value={editedContent}
            onChange={(e) => setEditedContent(e.target.value)}
            className="min-h-[100px]"
          />
          <DialogFooter>
            <Button onClick={saveEditedComment}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
