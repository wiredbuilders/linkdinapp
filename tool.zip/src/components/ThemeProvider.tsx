import { createContext, useContext, useEffect, useState } from "react";

type Theme = "dark" | "light" | "system";

type ThemeProviderProps = {
  children: React.ReactNode;
  defaultTheme?: Theme;
  storageKey?: string;
};

type ThemeProviderState = {
  theme: Theme;
  setTheme: (theme: Theme) => void;
};

const initialState: ThemeProviderState = {
  theme: "system",
  setTheme: () => null,
};

const ThemeProviderContext = createContext<ThemeProviderState>(initialState);

export function ThemeProvider({
  children,
  defaultTheme = "dark", // Changed default to dark
  storageKey = "ui-theme",
  ...props
}: ThemeProviderProps) {
  // Get initial theme with a fallback to the default
  const [theme, setTheme] = useState<Theme>(() => {
    // Try to get from localStorage
    const savedTheme = localStorage.getItem(storageKey) as Theme;
    // If valid theme found in storage, use it
    if (savedTheme && ["dark", "light", "system"].includes(savedTheme)) {
      return savedTheme;
    }
    // Otherwise use default
    return defaultTheme;
  });

  // Apply theme effect
  useEffect(() => {
    const root = window.document.documentElement;
    const body = document.body;
    
    // Debug log
    console.log("ThemeProvider: Setting theme to", theme);
    
    // Clean existing theme classes
    root.classList.remove("light", "dark");
    body.classList.remove("light-mode", "dark-mode");

    // If system preference
    if (theme === "system") {
      const systemTheme = window.matchMedia("(prefers-color-scheme: dark)")
        .matches
        ? "dark"
        : "light";

      // Apply system theme
      root.classList.add(systemTheme);
      root.setAttribute("data-theme", systemTheme);
      body.classList.add(`${systemTheme}-mode`);
      console.log("Applied system theme:", systemTheme);
      return;
    }

    // Apply explicit theme
    root.classList.add(theme);
    root.setAttribute("data-theme", theme);
    body.classList.add(`${theme}-mode`);
    
    // Debug log
    console.log("Applied theme:", theme);
  }, [theme]);

  const value = {
    theme,
    setTheme: (theme: Theme) => {
      localStorage.setItem(storageKey, theme);
      setTheme(theme);
    },
  };

  return (
    <ThemeProviderContext.Provider {...props} value={value}>
      {children}
    </ThemeProviderContext.Provider>
  );
}

export const useTheme = () => {
  const context = useContext(ThemeProviderContext);

  if (context === undefined)
    throw new Error("useTheme must be used within a ThemeProvider");

  return context;
};
