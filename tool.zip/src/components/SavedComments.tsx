import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { formatDistanceToNow } from "date-fns";
import { Copy, Trash2, Loader2 } from "lucide-react";
import { Comment } from "@shared/schema";
import { getSavedComments, deleteComment } from "@/lib/comments";

// Detect if we're running in static mode (no server)
const isStaticBuild = typeof window !== "undefined" && window.location.protocol === "file:";

export default function SavedComments() {
  const { toast } = useToast();

  const { data: comments, isLoading, error } = useQuery({
    queryKey: ["/api/comments"],
    queryFn: getSavedComments,
    staleTime: 30000, // 30 seconds
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      if (isStaticBuild) {
        // Use our direct function for static builds
        return await deleteComment(id);
      } else {
        // Original API call for server mode
        const response = await apiRequest("DELETE", `/api/comments/${id}`);
        return response.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/comments"] });
      toast({
        variant: "success",
        title: "Deleted",
        description: "Comment deleted from history",
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to delete comment",
      });
    },
  });

  const handleCopyComment = (content: string) => {
    navigator.clipboard.writeText(content);
    toast({
      variant: "success",
      title: "Copied",
      description: "Comment copied to clipboard",
    });
  };

  const handleDeleteComment = (id: number) => {
    deleteMutation.mutate(id);
  };

  if (isLoading) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 mb-6">
        <h2 className="font-semibold text-lg mb-3 text-linkedin-text dark:text-white">
          Saved Comments
        </h2>
        <div className="flex justify-center p-4">
          <Loader2 className="h-8 w-8 animate-spin text-linkedin-blue" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 mb-6">
        <h2 className="font-semibold text-lg mb-3 text-linkedin-text dark:text-white">
          Saved Comments
        </h2>
        <Card>
          <CardContent className="p-4 text-center text-destructive">
            Error loading comments
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 mb-6">
      <h2 className="font-semibold text-lg mb-3 text-linkedin-text dark:text-white">
        Saved Comments
      </h2>

      {comments && comments.length > 0 ? (
        <div className="divide-y divide-linkedin-gray dark:divide-gray-700">
          {comments.map((comment: Comment) => (
            <div className="py-3" key={comment.id}>
              <div className="flex justify-between mb-1">
                <span className="text-xs text-linkedin-darkGray dark:text-gray-400">
                  {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
                </span>
                <div className="flex space-x-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6"
                    title="Copy comment"
                    onClick={() => handleCopyComment(comment.content)}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6"
                    title="Delete comment"
                    onClick={() => handleDeleteComment(comment.id)}
                    disabled={deleteMutation.isPending}
                  >
                    {deleteMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Trash2 className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
              <p className="text-sm text-linkedin-text dark:text-white line-clamp-2">
                {comment.content}
              </p>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-4 text-linkedin-darkGray dark:text-gray-400">
          No saved comments yet
        </div>
      )}
    </div>
  );
}
