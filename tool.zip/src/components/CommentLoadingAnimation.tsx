import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface CommentLoadingAnimationProps {
  tone: string;
}

export default function CommentLoadingAnimation({ tone }: CommentLoadingAnimationProps) {
  const [loadingText, setLoadingText] = useState("Generating comments");
  const [dots, setDots] = useState("");
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState(0);
  
  // Simplified steps for faster animation
  const loadingSteps = [
    "Generating comments",
    `Crafting ${tone} tone variations`,
    "Finalizing response"
  ];
  
  // Loading text animation - faster transitions
  useEffect(() => {
    const textInterval = setInterval(() => {
      setCurrentStep(prev => {
        const newStep = prev < loadingSteps.length - 1 ? prev + 1 : prev;
        setLoadingText(loadingSteps[newStep]);
        return newStep;
      });
    }, 600); // Much faster transitions (was 2000ms)
    
    return () => clearInterval(textInterval);
  }, []);
  
  // Dot animation - faster animation
  useEffect(() => {
    const dotInterval = setInterval(() => {
      setDots(prev => {
        if (prev.length >= 3) return "";
        return prev + ".";
      });
    }, 200); // Faster dot animation (was 500ms)
    
    return () => clearInterval(dotInterval);
  }, []);
  
  // Progress animation - much faster progress
  useEffect(() => {
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) return 100;
        return prev + 8; // Much faster progress (was 2%)
      });
    }, 50); // Faster updates (was 100ms)
    
    return () => clearInterval(progressInterval);
  }, []);
  
  // Badge color based on tone
  const getBadgeColor = (tone: string) => {
    switch (tone) {
      case "professional":
        return "bg-blue-600";
      case "friendly":
        return "bg-yellow-500";
      case "funny":
        return "bg-purple-500";
      case "supportive":
        return "bg-green-600";
      case "insightful":
        return "bg-orange-500";
      case "storytelling":
        return "bg-pink-500";
      default:
        return "bg-gray-500";
    }
  };

  return (
    <div className="space-y-3 mb-6 relative">
      <div className="flex justify-between items-center mb-1">
        <h2 className="font-semibold text-lg text-linkedin-text dark:text-white flex items-center">
          <Loader2 className="w-5 h-5 mr-2 text-blue-600 animate-spin" />
          Loading Comments
        </h2>
      </div>
      
      {/* Fast-moving progress bar */}
      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5 mb-2">
        <div 
          className="bg-blue-600 h-1.5 rounded-full transition-all duration-150 ease-in-out"
          style={{ width: `${progress}%` }}
        ></div>
      </div>
      
      {/* Loading text - compact */}
      <div className="text-sm text-blue-600 dark:text-blue-400 font-medium mb-2">
        {loadingText}{dots}
      </div>
      
      {/* Faster pulsing animated placeholders */}
      <div className="space-y-2">
        <Card className="overflow-hidden shadow-sm border-gray-200 dark:border-gray-700">
          <CardContent className="p-3">
            <div className="flex justify-between mb-2">
              <div className="flex gap-2">
                <Badge className={`${getBadgeColor(tone)} capitalize text-xs`}>
                  {tone}
                </Badge>
              </div>
            </div>
            <div className="space-y-1.5 animate-[pulse_0.8s_cubic-bezier(0.4,0,0.6,1)_infinite]">
              <div className="h-1.5 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
              <div className="h-1.5 bg-gray-200 dark:bg-gray-700 rounded"></div>
              <div className="h-1.5 bg-gray-200 dark:bg-gray-700 rounded w-5/6"></div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="overflow-hidden shadow-sm border-gray-200 dark:border-gray-700">
          <CardContent className="p-3">
            <div className="flex justify-between mb-2">
              <div className="flex gap-2">
                <Badge className={`${getBadgeColor(tone)} capitalize text-xs`}>
                  {tone}
                </Badge>
              </div>
            </div>
            <div className="space-y-1.5 animate-[pulse_0.7s_cubic-bezier(0.4,0,0.6,1)_infinite]">
              <div className="h-1.5 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
              <div className="h-1.5 bg-gray-200 dark:bg-gray-700 rounded w-full"></div>
              <div className="h-1.5 bg-gray-200 dark:bg-gray-700 rounded w-3/5"></div>
            </div>
          </CardContent>
        </Card>
        
        {/* Add a one-liner placeholder */}
        <div className="bg-white dark:bg-gray-800 shadow-sm rounded-lg p-2 mt-4">
          <div className="p-2 mb-1 rounded-md flex items-center justify-between bg-gray-50 dark:bg-gray-700 border border-gray-100 dark:border-gray-700">
            <div className="flex items-center gap-2">
              <Badge className={`${getBadgeColor(tone)} capitalize text-xs px-2 py-0.5`}>
                {tone}
              </Badge>
              <div className="h-1.5 bg-gray-200 dark:bg-gray-600 rounded w-36 animate-[pulse_0.6s_cubic-bezier(0.4,0,0.6,1)_infinite]"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}