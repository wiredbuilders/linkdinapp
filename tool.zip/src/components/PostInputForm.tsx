import { useState, useRef, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { extractTextFromImage } from "@/lib/ocr";
import { extractContentFromUrl } from "@/lib/url-extractor";
import { generateComments, generatePlaceholderComments } from "@/lib/comments";
import { ToneOption, toneOptions } from "@shared/schema";
import { Clipboard, Link, Camera, Loader2, AlertTriangle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { deepseekService } from "@/services/deepseekService";
import { useLocation } from "wouter";

// Detect if we're running in static mode (no server)
const isStaticBuild = typeof window !== "undefined" && window.location.protocol === "file:";

interface PostInputFormProps {
  onGenerate: (comments: any[], postContent: string) => void;
  onGenerationStart?: (tone: string) => void;
}

export default function PostInputForm({ onGenerate, onGenerationStart }: PostInputFormProps) {
  const [activeTab, setActiveTab] = useState<string>("paste");
  const [postContent, setPostContent] = useState<string>("");
  const [postUrl, setPostUrl] = useState<string>("");
  const [selectedTone, setSelectedTone] = useState<ToneOption>("auto");
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Check for API key in static build
  const [hasApiKey, setHasApiKey] = useState(true);
  const [, navigate] = useLocation();
  
  // Check if API key is set on mount if static build
  useEffect(() => {
    if (isStaticBuild) {
      setHasApiKey(deepseekService.hasApiKey());
    }
  }, []);
  
  // Go to settings page to set API key
  const handleGoToSettings = () => {
    navigate("/settings");
  };
  
  // URL extraction mutation
  const urlMutation = useMutation({
    mutationFn: async (url: string) => {
      if (isStaticBuild) {
        // Use direct URL extractor for static build
        const content = await extractContentFromUrl(url);
        return { content };
      } else {
        // Regular API call
        const response = await apiRequest("POST", "/api/extract-from-url", { url });
        return response.json();
      }
    },
    onSuccess: (data) => {
      if (data.content) {
        setPostContent(data.content);
        setActiveTab("paste");
        toast({
          variant: "success",
          title: "Content extracted",
          description: "Successfully extracted content from URL",
        });
      }
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to extract content from URL",
      });
    },
  });

  // OCR image to text mutation
  const ocrMutation = useMutation({
    mutationFn: async (image: string) => {
      // Always try client-side OCR for speed and privacy
      try {
        const text = await extractTextFromImage(image);
        if (text) return { content: text };
      } catch (error) {
        console.error("Client-side OCR failed", error);
        
        // If we're not in static mode, we can fall back to server-side OCR
        if (!isStaticBuild) {
          // Fall back to server-side OCR if client-side fails
          const response = await apiRequest("POST", "/api/ocr", { image });
          return response.json();
        } else {
          throw new Error("OCR failed. Try manually entering the text instead.");
        }
      }
    },
    onSuccess: (data) => {
      if (data.content) {
        setPostContent(data.content);
        setActiveTab("paste");
        toast({
          variant: "success",
          title: "Text extracted",
          description: "Successfully extracted text from image",
        });
      }
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "OCR Error",
        description: error.message || "Failed to extract text from image",
      });
    },
  });

  // Comment generation mutation
  const generateMutation = useMutation({
    mutationFn: async () => {
      if (!postContent.trim()) {
        throw new Error("Please enter post content");
      }
      
      // Check for API key in static mode
      if (isStaticBuild && !deepseekService.hasApiKey()) {
        throw new Error("DeepSeek API key is required. Please add it in Settings.");
      }
      
      setIsGenerating(true);
      
      // Get placeholder comments to show immediately
      const placeholderComments = generatePlaceholderComments(postContent, selectedTone);
      
      // Show placeholder comments right away for immediate response
      setTimeout(() => {
        onGenerate(placeholderComments, postContent);
      }, 700); // Show after minimum loading time
      
      // Start the real generation
      if (isStaticBuild) {
        // Use direct generateComments function for static build
        const comments = await generateComments(postContent, selectedTone);
        return { comments };
      } else {
        // Regular API call
        const response = await apiRequest("POST", "/api/comments/generate", {
          content: postContent,
          tone: selectedTone,
        });
        return response.json();
      }
    },
    onSuccess: (data) => {
      if (data.comments && data.comments.length > 0) {
        // Update with real comments once they arrive
        onGenerate(data.comments, postContent);
        toast({
          variant: "success",
          title: "Success",
          description: "Comments generated successfully!",
        });
      } else {
        toast({
          variant: "destructive",
          title: "Error",
          description: "No comments were generated",
        });
      }
      setIsGenerating(false);
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to generate comments",
      });
      setIsGenerating(false);
    },
  });

  const handleFetchFromUrl = () => {
    if (!postUrl.trim()) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please enter a valid URL",
      });
      return;
    }
    urlMutation.mutate(postUrl);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      if (typeof event.target?.result === "string") {
        ocrMutation.mutate(event.target.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleGenerate = () => {
    // Notify parent component that generation is starting
    if (onGenerationStart) {
      onGenerationStart(selectedTone);
    }
    
    // Start the mutation
    generateMutation.mutate();
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-5 mb-6">
      <h2 className="font-semibold text-xl mb-3 text-linkedin-text dark:text-white flex items-center">
        <Clipboard className="w-5 h-5 mr-2 text-blue-600" />
        Create LinkedIn Comments
      </h2>
      <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
        Generate natural, human-like comments for LinkedIn posts with different styles and tones.
      </p>

      {isStaticBuild && !hasApiKey && (
        <Alert className="mb-4 border-yellow-500 bg-yellow-50 dark:bg-yellow-900/20">
          <AlertTriangle className="h-4 w-4 text-yellow-600 dark:text-yellow-500" />
          <AlertDescription className="flex items-center justify-between">
            <span>You need to set up your DeepSeek API key to generate comments in static mode.</span>
            <Button 
              onClick={handleGoToSettings}
              size="sm"
              variant="outline"
              className="border-yellow-500 text-yellow-600 hover:bg-yellow-50 dark:text-yellow-500 dark:hover:bg-yellow-900/40 ml-2"
            >
              Go to Settings
            </Button>
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="paste" value={activeTab} onValueChange={setActiveTab} className="mt-4">
        <TabsList className="mb-4 w-full grid grid-cols-3 gap-2">
          <TabsTrigger value="paste" className="flex items-center justify-center">
            <Clipboard className="w-4 h-4 mr-2" />
            Paste Content
          </TabsTrigger>
          <TabsTrigger value="url" className="flex items-center justify-center">
            <Link className="w-4 h-4 mr-2" />
            From URL
          </TabsTrigger>
          <TabsTrigger value="ocr" className="flex items-center justify-center">
            <Camera className="w-4 h-4 mr-2" />
            From Image
          </TabsTrigger>
        </TabsList>

        <TabsContent value="paste" className="mb-5">
          <div className="bg-gray-50 dark:bg-gray-700 rounded-md p-3 mb-2">
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">Paste the LinkedIn post content below:</p>
            <Textarea
              placeholder="Enter the LinkedIn post you want to comment on..."
              className="w-full h-32 resize-none focus:border-blue-500"
              value={postContent}
              onChange={(e) => setPostContent(e.target.value)}
            />
          </div>
        </TabsContent>

        <TabsContent value="url" className="mb-5">
          <div className="bg-gray-50 dark:bg-gray-700 rounded-md p-3 mb-2">
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">Enter the LinkedIn post URL to extract content:</p>
            <div className="flex">
              <Input
                type="url"
                placeholder="https://www.linkedin.com/posts/username-123456..."
                value={postUrl}
                onChange={(e) => setPostUrl(e.target.value)}
                className="rounded-r-none border-r-0 focus:border-blue-500"
              />
              <Button
                onClick={handleFetchFromUrl}
                className="rounded-l-none bg-blue-600 hover:bg-blue-700"
                disabled={urlMutation.isPending}
              >
                {urlMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : null}
                Extract
              </Button>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="ocr" className="mb-5">
          <div className="bg-gray-50 dark:bg-gray-700 rounded-md p-3 mb-2">
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">Upload a screenshot of a LinkedIn post:</p>
            <div className="border-2 border-dashed border-blue-300 dark:border-blue-800 rounded-lg p-8 text-center bg-white dark:bg-gray-800 transition-all hover:border-blue-500">
              <Camera className="h-12 w-12 mx-auto text-blue-500 dark:text-blue-400 mb-2" />
              <p className="mb-4 text-gray-600 dark:text-gray-300">
                Drag and drop an image or click to browse
              </p>
              <Input
                type="file"
                accept="image/*"
                ref={fileInputRef}
                onChange={handleImageUpload}
                className="hidden"
              />
              <Button
                onClick={() => fileInputRef.current?.click()}
                disabled={ocrMutation.isPending}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {ocrMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : null}
                Upload Screenshot
              </Button>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      <div className="border-t border-gray-200 dark:border-gray-700 pt-4 mb-5">
        <div className="flex flex-col md:flex-row md:items-center gap-4">
          <div className="flex-1">
            <Label htmlFor="tone-select" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Comment Tone
            </Label>
            <Select
              value={selectedTone}
              onValueChange={(value) => setSelectedTone(value as ToneOption)}
            >
              <SelectTrigger id="tone-select" className="w-full">
                <SelectValue placeholder="Select tone" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="auto" className="font-semibold">
                  Auto (AI selects the best tone)
                </SelectItem>
                <SelectItem value="professional">Professional</SelectItem>
                <SelectItem value="friendly">Friendly</SelectItem>
                <SelectItem value="funny">Funny</SelectItem>
                <SelectItem value="supportive">Supportive</SelectItem>
                <SelectItem value="insightful">Insightful</SelectItem>
                <SelectItem value="storytelling">Storytelling</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <Button
        className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2"
        onClick={handleGenerate}
        disabled={isGenerating || !postContent.trim()}
      >
        {isGenerating ? (
          <>
            <Loader2 className="mr-2 h-5 w-5 animate-spin" />
            Creating Comments...
          </>
        ) : (
          "Generate Comments"
        )}
      </Button>
      
      {postContent.trim() && !isGenerating && (
        <p className="text-xs text-gray-500 dark:text-gray-400 mt-2 text-center">
          Will generate multiple comment variations including one-liners
        </p>
      )}
    </div>
  );
}
