import { Link, useLocation } from "wouter";
import { MessageSquare, History, Settings } from "lucide-react";

export default function BottomNav() {
  const [location] = useLocation();

  const getNavItemClass = (path: string) => {
    const baseClass = "flex flex-col items-center py-3 px-5";
    return location === path
      ? `${baseClass} text-linkedin-blue`
      : `${baseClass} text-linkedin-darkGray dark:text-gray-400`;
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 shadow-lg border-t border-linkedin-gray dark:border-gray-700">
      <div className="max-w-md mx-auto flex justify-around">
        <Link href="/">
          <a className={getNavItemClass("/")}>
            <MessageSquare className="h-5 w-5" />
            <span className="text-xs mt-1">Generate</span>
          </a>
        </Link>
        
        <Link href="/history">
          <a className={getNavItemClass("/history")}>
            <History className="h-5 w-5" />
            <span className="text-xs mt-1">History</span>
          </a>
        </Link>
        
        <Link href="/settings">
          <a className={getNavItemClass("/settings")}>
            <Settings className="h-5 w-5" />
            <span className="text-xs mt-1">Settings</span>
          </a>
        </Link>
      </div>
    </nav>
  );
}
