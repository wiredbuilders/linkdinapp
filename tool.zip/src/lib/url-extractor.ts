import { apiRequest } from "@/lib/queryClient";
import { extractFromUrlSchema } from "@shared/schema";
import { deepseekService } from "@/services/deepseekService";

// Detect if we're running in static mode (no server)
const isStaticBuild = typeof window !== "undefined" && window.location.protocol === "file:";

export async function extractContentFromUrl(url: string): Promise<string> {
  try {
    // Validate the URL
    const validationResult = extractFromUrlSchema.safeParse({ url });
    if (!validationResult.success) {
      throw new Error(validationResult.error.message);
    }

    // If static build, use our direct service
    if (isStaticBuild) {
      const content = await deepseekService.extractFromUrl(url);
      if (!content) {
        throw new Error("No content could be extracted from the URL");
      }
      return content;
    } else {
      // Regular API call
      const response = await apiRequest("POST", "/api/extract-from-url", { url });
      const data = await response.json();
      
      if (!data.content) {
        throw new Error("No content could be extracted from the URL");
      }
      
      return data.content;
    }
  } catch (error: any) {
    console.error("Error extracting content from URL:", error);
    throw new Error(error.message || "Failed to extract content from URL");
  }
}
