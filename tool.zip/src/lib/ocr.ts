// Client-side OCR functionality using Tesseract.js
import Tesseract from 'tesseract.js';
import { deepseekService } from '@/services/deepseekService';

// Detect if we're running in static mode (no server)
const isStaticBuild = typeof window !== "undefined" && window.location.protocol === "file:";

export async function extractTextFromImage(imageData: string): Promise<string> {
  try {
    // If static build, use our deepseekService
    if (isStaticBuild) {
      return await deepseekService.extractTextFromImage(imageData);
    }
    
    // Regular client-side processing
    const result = await Tesseract.recognize(
      imageData,
      'eng',
      { 
        logger: m => console.debug('[OCR]', m)
      }
    );
    
    return result.data.text;
  } catch (error) {
    console.error("Error in OCR:", error);
    throw new Error("Failed to extract text from image");
  }
}
