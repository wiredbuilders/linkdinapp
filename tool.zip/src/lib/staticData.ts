// This file contains static data that will be used when the app is built as a static site
// It replaces the API calls with pre-loaded data

import { ToneOption } from "@shared/schema";

// Example comments to be displayed
export const staticComments = [
  {
    id: 1,
    content: "This is exactly what I needed to hear today. Your insights on LinkedIn strategy are spot on and have already helped me revamp my approach. Thanks for sharing your expertise!",
    tone: "professional" as ToneOption,
    originalPost: "I've been working on LinkedIn strategy for 5 years now, and I've found that consistency is key. Post at least 3 times a week, engage with others' content, and focus on providing value rather than selling.",
    createdAt: new Date(),
    userId: 1,
  },
  {
    id: 2,
    content: "Love how you break this down! 🙌 I've been struggling with my LinkedIn content, but your simple approach makes it seem much more doable. Definitely saving this post!",
    tone: "friendly" as ToneOption,
    originalPost: "I've been working on LinkedIn strategy for 5 years now, and I've found that consistency is key. Post at least 3 times a week, engage with others' content, and focus on providing value rather than selling.",
    createdAt: new Date(),
    userId: 1,
  },
  {
    id: 3,
    content: "Consistency is indeed everything! Been there, done that, got the t-shirt with the LinkedIn logo on it. 😂 Still working on the 'not selling' part though... my sales manager keeps asking why I'm not in people's DMs with our latest offer!",
    tone: "funny" as ToneOption,
    originalPost: "I've been working on LinkedIn strategy for 5 years now, and I've found that consistency is key. Post at least 3 times a week, engage with others' content, and focus on providing value rather than selling.",
    createdAt: new Date(),
    userId: 1,
  }
];

// Sample generated comments for the home page
export const sampleGeneratedComments = [
  {
    content: "I appreciate how you've distilled 5 years of LinkedIn expertise into such actionable advice. The emphasis on consistency and value-first approach resonates strongly with what I've observed from successful profiles. Your insights are incredibly valuable!",
    tone: "professional",
    type: "standard"
  },
  {
    content: "This is exactly what I needed to read today! I've been so inconsistent with my LinkedIn strategy. Your advice to post 3x weekly and focus on value is a game-changer. Thanks for sharing your wisdom!",
    tone: "friendly",
    type: "standard"
  },
  {
    content: "Five years of LinkedIn strategy and all I've been doing is posting cat memes... no wonder my network consists of veterinarians and pet food companies! 😂 Seriously though, great tips on consistency!",
    tone: "funny",
    type: "standard"
  },
  {
    content: "Consistency really is the secret sauce! Thanks for the reminder.",
    tone: "supportive",
    type: "one-line"
  },
  {
    content: "Your LinkedIn wisdom is worth its weight in gold. Bookmarked!",
    tone: "insightful",
    type: "one-line"
  }
];

// Example LinkedIn post for demonstration
export const samplePost = "I've been working on LinkedIn strategy for 5 years now, and I've found that consistency is key. Post at least 3 times a week, engage with others' content, and focus on providing value rather than selling.";

// Function to simulate a delay like a real API call
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Mock API functions that return static data
export const mockApi = {
  async getComments() {
    await delay(300);
    return staticComments;
  },
  
  async generateComments(content: string, tone: ToneOption) {
    await delay(1500); // Simulate API delay
    return { comments: sampleGeneratedComments };
  },
  
  async saveComment(content: string, tone: ToneOption, originalPost: string) {
    await delay(200);
    const newComment = {
      id: Date.now(),
      content,
      tone,
      originalPost,
      createdAt: new Date(),
      userId: 1
    };
    return newComment;
  },
  
  async deleteComment(id: number) {
    await delay(200);
    return { success: true };
  },
  
  async extractFromUrl(url: string) {
    await delay(800);
    return { content: samplePost };
  },
  
  async ocrFromImage(image: string) {
    await delay(1200);
    return { content: samplePost };
  }
};