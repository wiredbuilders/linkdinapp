import { apiRequest } from "@/lib/queryClient";
import { ToneOption, generateCommentsSchema } from "@shared/schema";
import { deepseekService } from "@/services/deepseekService";
import { staticComments } from "@/lib/staticData";

// Detect if we're running in static mode (no server)
const isStaticBuild = typeof window !== "undefined" && window.location.protocol === "file:";

// Local storage for saved comments in static mode
let savedComments: any[] = [];

// Try to load saved comments from localStorage in static mode
if (isStaticBuild && typeof localStorage !== "undefined") {
  try {
    const savedData = localStorage.getItem("saved_comments");
    if (savedData) {
      savedComments = JSON.parse(savedData);
    } else {
      // Initialize with static data the first time
      savedComments = staticComments;
      localStorage.setItem("saved_comments", JSON.stringify(savedComments));
    }
  } catch (e) {
    console.error("Failed to load saved comments from localStorage", e);
    savedComments = staticComments;
  }
}

export interface CommentData {
  content: string;
  tone: ToneOption;
}

// Fast comment templates for immediate initial display
// These help create a faster perceived response time
const quickResponseTemplates: Record<ToneOption, string[]> = {
  auto: [
    "This perspective is valuable! Thanks for sharing.",
    "Interesting take. I've been thinking about this too."
  ],
  professional: [
    "Excellent points. This aligns with best practices in the industry.",
    "Well articulated perspective. I appreciate the strategic analysis here."
  ],
  friendly: [
    "Love this! So relatable and helpful!",
    "This resonates with me so much! Thanks for sharing!"
  ],
  funny: [
    "This is too accurate! 😂 Feeling called out in the best way.",
    "Haha, this is exactly what happens every time!"
  ],
  supportive: [
    "Thank you for sharing this important message. We need more voices like yours.",
    "Really appreciate you bringing attention to this! Supporting your journey."
  ],
  insightful: [
    "The pattern you've identified here is fascinating and often overlooked.",
    "This perspective adds a crucial dimension to the conversation."
  ],
  storytelling: [
    "This reminds me of my own journey. The parallels are striking!",
    "Your story resonates with my experiences. These lessons are timeless."
  ]
};

// Function to generate placeholder comments based on content length and tone
export function generatePlaceholderComments(content: string, tone: ToneOption): CommentData[] {
  // Default to professional tone templates if auto is selected
  const templates = tone === 'auto' ? quickResponseTemplates.professional : quickResponseTemplates[tone];
  
  // Create comment objects from templates
  return templates.map(template => ({
    content: template,
    tone: tone
  }));
}

export async function generateComments(
  content: string,
  tone: ToneOption
): Promise<CommentData[]> {
  try {
    // Validate the request data
    const validationResult = generateCommentsSchema.safeParse({ content, tone });
    if (!validationResult.success) {
      throw new Error(validationResult.error.message);
    }

    // Generate placeholder comments first to use if needed
    const placeholderComments = generatePlaceholderComments(content, tone);
    
    try {
      // If static build, use direct DeepSeek API
      if (isStaticBuild) {
        const data = await deepseekService.generateComments(content, tone);
        return data.comments || placeholderComments;
      } else {
        // Regular server-side API call for development/production
        const response = await apiRequest("POST", "/api/comments/generate", {
          content,
          tone,
        });

        const data = await response.json();
        return data.comments || placeholderComments;
      }
    } catch (apiError) {
      console.error("API error, returning placeholder comments:", apiError);
      // Return placeholders if API fails
      return placeholderComments;
    }
  } catch (error: any) {
    console.error("Error generating comments:", error);
    throw new Error(error.message || "Failed to generate comments");
  }
}

export async function saveComment(
  content: string,
  tone: ToneOption,
  originalPost: string
): Promise<any> {
  try {
    // If static build, save to localStorage
    if (isStaticBuild) {
      const newComment = {
        id: Date.now(),
        content,
        tone,
        originalPost,
        createdAt: new Date().toISOString(),
        userId: null
      };
      
      savedComments.push(newComment);
      localStorage.setItem("saved_comments", JSON.stringify(savedComments));
      return newComment;
    } else {
      // Regular API call
      const response = await apiRequest("POST", "/api/comments", {
        content,
        tone,
        originalPost,
      });

      return await response.json();
    }
  } catch (error: any) {
    console.error("Error saving comment:", error);
    throw new Error(error.message || "Failed to save comment");
  }
}

export async function deleteComment(id: number): Promise<any> {
  try {
    // If static build, remove from localStorage
    if (isStaticBuild) {
      savedComments = savedComments.filter(comment => comment.id !== id);
      localStorage.setItem("saved_comments", JSON.stringify(savedComments));
      return { message: "Comment deleted successfully" };
    } else {
      // Regular API call
      const response = await apiRequest("DELETE", `/api/comments/${id}`);
      return await response.json();
    }
  } catch (error: any) {
    console.error("Error deleting comment:", error);
    throw new Error(error.message || "Failed to delete comment");
  }
}

// Function to get all saved comments
export async function getSavedComments(): Promise<any[]> {
  try {
    // If static build, get from localStorage
    if (isStaticBuild) {
      return savedComments;
    } else {
      // Regular API call
      const response = await apiRequest("GET", "/api/comments");
      return await response.json();
    }
  } catch (error: any) {
    console.error("Error fetching comments:", error);
    throw new Error(error.message || "Failed to fetch comments");
  }
}
