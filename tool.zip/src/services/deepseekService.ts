import axios from "axios";
import { ToneOption, toneOptions } from "@shared/schema";
import { createWorker } from "tesseract.js";
import * as cheerio from "cheerio";

// DeepSeek direct API integration for frontend
export class DeepseekService {
  private apiKey: string | null = null;
  
  constructor() {
    // Try to load from localStorage first (saved in settings)
    this.apiKey = localStorage.getItem("deepseek_api_key");
  }
  
  // Set API key
  setApiKey(key: string) {
    this.apiKey = key;
    localStorage.setItem("deepseek_api_key", key);
  }
  
  // Get API key - returns null if not set
  getApiKey(): string | null {
    return this.apiKey;
  }
  
  // Check if API key is set
  hasApiKey(): boolean {
    return !!this.apiKey;
  }
  
  // Generate comments directly with the DeepSeek API
  async generateComments(content: string, tone: ToneOption): Promise<any> {
    if (!this.apiKey) {
      throw new Error("DeepSeek API key is not set. Please set it in the settings page.");
    }
    
    // Auto-detect tone if set to 'auto'
    let actualTone = tone;
    if (tone === 'auto') {
      try {
        const autoToneResponse = await axios.post(
          "https://api.deepseek.com/v1/chat/completions",
          {
            model: "deepseek-chat",
            messages: [{ 
              role: "user", 
              content: `Analyze the following LinkedIn post and suggest the most appropriate tone for a comment from these options: professional, friendly, funny, supportive, insightful, storytelling. Only respond with one word - the tone name. Post: "${content}"` 
            }],
            temperature: 0.3,
            max_tokens: 20
          },
          {
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${this.apiKey}`
            }
          }
        );

        if (autoToneResponse.data?.choices?.[0]) {
          const suggestedTone = autoToneResponse.data.choices[0].message.content.trim().toLowerCase();
          // Check if the suggested tone is one of our valid options
          if (toneOptions.includes(suggestedTone as ToneOption)) {
            actualTone = suggestedTone as ToneOption;
          } else {
            // Default to professional if the returned tone isn't recognized
            actualTone = 'professional';
          }
        }
      } catch (error) {
        console.error("Error in auto tone detection:", error);
        actualTone = 'professional'; // Default if auto-detection fails
      }
    }

    // Define comment types to generate
    const commentTypes = [
      { type: 'standard', description: 'a concise and engaging comment' },
      { type: 'one-line', description: 'a very brief one-line comment' }
    ];
    
    // Generate variations with different styles
    const variations = [];
    
    // Make API calls to DeepSeek for different comment types
    for (const commentType of commentTypes) {
      // Prepare prompt based on tone and type
      let prompt = '';
      
      if (actualTone === 'storytelling') {
        prompt = `Write ${commentType.description} for this LinkedIn post that shares a brief personal story or anecdote related to the topic. Make it sound completely natural, conversational and human-written (not AI-generated). No instructions or explanations - just the direct comment text. Here's the post: "${content}"`;
      } else {
        prompt = `Write ${commentType.description} for this LinkedIn post in a ${actualTone} tone. Make it sound completely natural, conversational and human-written (not AI-generated). No instructions or explanations - just the direct comment text. Here's the post: "${content}"`;
      }
      
      const response = await axios.post(
        "https://api.deepseek.com/v1/chat/completions",
        {
          model: "deepseek-chat",
          messages: [{ role: "user", content: prompt }],
          temperature: 0.7,
          max_tokens: commentType.type === 'one-line' ? 100 : 200
        },
        {
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${this.apiKey}`
          }
        }
      );

      if (response.data?.choices?.[0]) {
        const commentText = response.data.choices[0].message.content.trim();
        variations.push({
          content: commentText,
          tone: actualTone,
          type: commentType.type
        });
      }
    }

    return { comments: variations };
  }

  // Extract text from a URL
  async extractFromUrl(url: string): Promise<string> {
    try {
      // For the static version, we'll use a CORS proxy if needed
      const corsProxy = "https://corsproxy.io/?";
      const finalUrl = url.startsWith('http') ? corsProxy + encodeURIComponent(url) : corsProxy + encodeURIComponent('https://' + url);
      
      const response = await axios.get(finalUrl);
      const html = response.data;
      
      // Use cheerio for HTML parsing
      const $ = cheerio.load(html);
      
      // Try to find the post content using various selectors
      // LinkedIn's structure can change, so we'll try multiple potential selectors
      const potentialSelectors = [
        '.feed-shared-update-v2__description',
        '.feed-shared-text',
        'article p',
        '.share-update-card__update-text',
        '.post-view .share-update-card__update-text-container'
      ];
      
      let postContent = "";
      for (const selector of potentialSelectors) {
        const element = $(selector);
        if (element.length > 0) {
          postContent = element.text().trim();
          if (postContent) break;
        }
      }
      
      if (!postContent) {
        // If specific selectors fail, try getting all paragraph text
        postContent = $('p').map((i, el) => $(el).text().trim()).get().join(' ');
      }
      
      return postContent || "Could not extract content from URL";
    } catch (error) {
      console.error("Error extracting URL content:", error);
      throw new Error("Failed to extract content from URL. Make sure the URL is valid and publicly accessible.");
    }
  }

  // Process image with OCR
  async extractTextFromImage(imageData: string): Promise<string> {
    try {
      // Process with Tesseract.js
      const worker = await createWorker();
      const { data } = await worker.recognize(imageData);
      await worker.terminate();
      
      if (data.text && data.text.trim()) {
        return data.text.trim();
      } else {
        throw new Error("Could not extract text from image");
      }
    } catch (error) {
      console.error("OCR error:", error);
      throw new Error("Failed to extract text from image");
    }
  }
}

// Create singleton instance
export const deepseekService = new DeepseekService();