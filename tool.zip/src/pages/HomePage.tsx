import { useState, useEffect } from "react";
import PostInputForm from "@/components/PostInputForm";
import GeneratedComments from "@/components/GeneratedComments";
import SavedComments from "@/components/SavedComments";
import CommentLoadingAnimation from "@/components/CommentLoadingAnimation";

interface Comment {
  content: string;
  tone: string;
}

export default function HomePage() {
  const [generatedComments, setGeneratedComments] = useState<Comment[]>([]);
  const [originalPost, setOriginalPost] = useState<string>("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedTone, setSelectedTone] = useState("professional");
  const [loadingTimeoutId, setLoadingTimeoutId] = useState<number | null>(null);

  // Force the loading animation to show for a minimal amount of time
  // to prevent UI flashing when generation is very fast
  useEffect(() => {
    return () => {
      // Clean up timeout on unmount
      if (loadingTimeoutId) {
        clearTimeout(loadingTimeoutId);
      }
    };
  }, [loadingTimeoutId]);

  const handleGenerateComments = (comments: Comment[], postContent: string) => {
    // If we're still in the loading animation, delay showing results
    if (isGenerating) {
      const minLoadingTime = 700; // ms - minimum time to show loading animation
      
      // Make sure the animation shows for at least minLoadingTime
      const id = window.setTimeout(() => {
        setGeneratedComments(comments);
        setOriginalPost(postContent);
        setIsGenerating(false);
      }, minLoadingTime);
      
      setLoadingTimeoutId(id);
    } else {
      // If generation was already shown as complete
      setGeneratedComments(comments);
      setOriginalPost(postContent);
    }
  };
  
  // Handle when generation starts
  const handleGenerationStart = (tone: string) => {
    setIsGenerating(true);
    setSelectedTone(tone);
    // Clear previous comments during generation
    setGeneratedComments([]);
    
    // Show loading for at least a short time
    const id = window.setTimeout(() => {
      // This timeout will be cleared if handleGenerateComments is called first
    }, 2000);
    setLoadingTimeoutId(id);
  };

  return (
    <main className="px-4 py-6">
      <PostInputForm 
        onGenerate={(comments, postContent) => handleGenerateComments(comments, postContent)}
        onGenerationStart={handleGenerationStart}
      />
      
      {isGenerating ? (
        <CommentLoadingAnimation tone={selectedTone} />
      ) : (
        <GeneratedComments 
          comments={generatedComments} 
          originalPost={originalPost} 
        />
      )}
      
      <SavedComments />
    </main>
  );
}
