import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import { Copy, ExternalLink, Trash2, Loader2 } from "lucide-react";
import { Comment } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";

export default function HistoryPage() {
  const { toast } = useToast();

  const { data: comments, isLoading, error } = useQuery({
    queryKey: ["/api/comments"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/comments/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/comments"] });
      toast({
        variant: "success",
        title: "Deleted",
        description: "Comment deleted from history",
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to delete comment",
      });
    },
  });

  const handleCopyComment = (content: string) => {
    navigator.clipboard.writeText(content);
    toast({
      variant: "success",
      title: "Copied",
      description: "Comment copied to clipboard",
    });
  };

  const handleShareToLinkedIn = (content: string) => {
    const encodedText = encodeURIComponent(content);
    window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodedText}`, "_blank");
  };

  const handleDeleteComment = (id: number) => {
    deleteMutation.mutate(id);
  };

  const getBadgeColor = (tone: string) => {
    switch (tone) {
      case "professional":
        return "bg-linkedin-blue";
      case "friendly":
        return "bg-yellow-500";
      case "funny":
        return "bg-purple-500";
      case "supportive":
        return "bg-green-600";
      case "insightful":
        return "bg-orange-500";
      default:
        return "bg-gray-500";
    }
  };

  if (isLoading) {
    return (
      <main className="px-4 py-6">
        <h1 className="font-bold text-xl mb-4 text-linkedin-text dark:text-white">
          Comment History
        </h1>
        <div className="flex justify-center p-8">
          <Loader2 className="h-8 w-8 animate-spin text-linkedin-blue" />
        </div>
      </main>
    );
  }

  if (error) {
    return (
      <main className="px-4 py-6">
        <h1 className="font-bold text-xl mb-4 text-linkedin-text dark:text-white">
          Comment History
        </h1>
        <Card>
          <CardContent className="p-4 text-center text-destructive">
            Error loading comment history
          </CardContent>
        </Card>
      </main>
    );
  }

  return (
    <main className="px-4 py-6">
      <h1 className="font-bold text-xl mb-4 text-linkedin-text dark:text-white">
        Comment History
      </h1>

      {comments && comments.length > 0 ? (
        <div className="space-y-4">
          {comments.map((comment: Comment) => (
            <Card key={comment.id}>
              <CardContent className="p-4">
                <div className="flex justify-between mb-2">
                  <Badge className={`${getBadgeColor(comment.tone)} capitalize`}>
                    {comment.tone}
                  </Badge>
                  <span className="text-xs text-linkedin-darkGray dark:text-gray-400">
                    {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
                  </span>
                </div>
                <p className="text-linkedin-text dark:text-white mb-3">
                  {comment.content}
                </p>
                <div className="flex justify-end space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleCopyComment(comment.content)}
                  >
                    <Copy className="h-4 w-4 mr-1" /> Copy
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleShareToLinkedIn(comment.content)}
                  >
                    <ExternalLink className="h-4 w-4 mr-1" /> Share
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-destructive"
                    onClick={() => handleDeleteComment(comment.id)}
                  >
                    <Trash2 className="h-4 w-4 mr-1" /> Delete
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-linkedin-darkGray dark:text-gray-400 mb-4">
              No saved comments yet
            </p>
            <Button variant="outline" onClick={() => window.location.href = "/"}>
              Generate Some Comments
            </Button>
          </CardContent>
        </Card>
      )}
    </main>
  );
}
