import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useTheme } from "@/components/ThemeProvider";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { MoonIcon, SunIcon, TrashIcon, KeyIcon, AlertTriangleIcon } from "lucide-react";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { deepseekService } from "@/services/deepseekService";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

// Detect if we're running in static mode (no server)
const isStaticBuild = typeof window !== "undefined" && window.location.protocol === "file:";

export default function SettingsPage() {
  const { theme, setTheme } = useTheme();
  const { toast } = useToast();
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [apiKey, setApiKey] = useState("");
  
  // Load API key on component mount for static builds
  useEffect(() => {
    if (isStaticBuild) {
      const savedKey = deepseekService.getApiKey();
      if (savedKey) {
        setApiKey(savedKey);
      }
    }
  }, []);
  
  // Initialize dark mode state from theme
  useEffect(() => {
    setIsDarkMode(theme === "dark");
  }, [theme]);

  // Handle dark mode toggle
  const handleDarkModeToggle = (checked: boolean) => {
    const newTheme = checked ? "dark" : "light";
    setIsDarkMode(checked);
    setTheme(newTheme);
    
    // Force a document class update in case the theme provider didn't catch it
    document.documentElement.classList.remove("light", "dark");
    document.documentElement.classList.add(newTheme);
    
    console.log("Settings page switched theme to:", newTheme);
    
    toast({
      title: `${checked ? "Dark" : "Light"} mode activated`,
      description: `Switched to ${checked ? "dark" : "light"} theme`,
      duration: 1500,
    });
  };
  
  // Save API key function
  const handleSaveApiKey = () => {
    if (!apiKey.trim()) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please enter a valid DeepSeek API key",
      });
      return;
    }
    
    try {
      // Save API key
      deepseekService.setApiKey(apiKey);
      
      toast({
        variant: "success",
        title: "Success",
        description: "DeepSeek API key saved successfully",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to save API key",
      });
    }
  };
  
  // Clear history mutation
  const clearHistoryMutation = useMutation({
    mutationFn: async () => {
      if (isStaticBuild) {
        // For static builds, clear localStorage
        localStorage.removeItem("saved_comments");
        return true;
      } else {
        // In regular app, we would make an API call to clear history
        // For now, we'll just invalidate the cache
        return Promise.resolve(true);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/comments"] });
      toast({
        variant: "success",
        title: "Success",
        description: "Comment history cleared",
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive", 
        title: "Error",
        description: error.message || "Failed to clear history",
      });
    }
  });

  const handleClearHistory = () => {
    clearHistoryMutation.mutate();
  };

  return (
    <main className="px-4 py-6 max-w-4xl mx-auto">
      <h1 className="font-bold text-xl mb-4 text-gray-800 dark:text-white flex items-center">
        <SunIcon className="mr-2 h-5 w-5 text-blue-600" />
        App Settings
      </h1>

      <div className="space-y-6">
        <Card className="border-blue-100 dark:border-blue-900">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Theme Preferences</CardTitle>
            <CardDescription>
              Customize the appearance of your LinkedIn Comment Generator
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  {isDarkMode ? (
                    <MoonIcon className="h-6 w-6 text-blue-500" />
                  ) : (
                    <SunIcon className="h-6 w-6 text-yellow-500" />
                  )}
                  <div>
                    <Label htmlFor="theme-mode" className="font-medium">Dark Mode</Label>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                      Switch between light and dark themes
                    </p>
                  </div>
                </div>
                <Switch
                  id="theme-mode"
                  checked={isDarkMode}
                  onCheckedChange={handleDarkModeToggle}
                  className="data-[state=checked]:bg-blue-600"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {isStaticBuild && (
          <Card className="border-blue-100 dark:border-blue-900">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-medium">API Settings</CardTitle>
              <CardDescription>
                Configure your DeepSeek API access
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                <Alert className="mb-4 border-yellow-500 bg-yellow-50 dark:bg-yellow-900/20">
                  <AlertTriangleIcon className="h-4 w-4 text-yellow-600 dark:text-yellow-500" />
                  <AlertTitle>Important</AlertTitle>
                  <AlertDescription>
                    Since you're using the static version of this app, you need to provide your DeepSeek API key to enable comment generation.
                  </AlertDescription>
                </Alert>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <KeyIcon className="h-5 w-5 text-blue-500 mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300">DeepSeek API Key</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 mb-3">
                        Enter your DeepSeek API key to enable comment generation functionality.
                      </p>
                      <div className="space-y-2">
                        <Input
                          type="password"
                          value={apiKey}
                          onChange={(e) => setApiKey(e.target.value)}
                          placeholder="Enter your DeepSeek API key"
                          className="w-full"
                        />
                        <Button 
                          onClick={handleSaveApiKey}
                          size="sm"
                          className="bg-blue-600 hover:bg-blue-700 text-white"
                        >
                          Save API Key
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Card className="border-blue-100 dark:border-blue-900">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Data Management</CardTitle>
            <CardDescription>
              Manage your saved comments and history
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <TrashIcon className="h-5 w-5 text-red-500 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Clear Comment History</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 mb-3">
                      Remove all saved comments from your history. This action cannot be undone.
                    </p>
                    <Button 
                      variant="destructive" 
                      size="sm"
                      onClick={handleClearHistory}
                      disabled={clearHistoryMutation.isPending}
                      className="bg-red-600 hover:bg-red-700"
                    >
                      {clearHistoryMutation.isPending ? "Clearing..." : "Clear History"}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
