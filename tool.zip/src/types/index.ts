import { ToneOption } from "@shared/schema";

export interface Comment {
  id: number;
  content: string;
  tone: ToneOption;
  originalPost: string;
  createdAt: Date;
  userId?: number | null;
}

export interface GeneratedComment {
  content: string;
  tone: ToneOption;
}

export interface ToastProps {
  message: string;
  type?: "success" | "error" | "info";
}
